# pages/wedding_cakes_catalog/wedding_cakes_catalog.py
from flask import Blueprint, render_template, request, session, redirect
from pymongo import MongoClient


weddingcakescatalog = Blueprint('weddingcakescatalog', __name__, static_folder='static', static_url_path='/pages/weddingcakescatalog',
                   template_folder='templates')

#
# @weddingcakescatalog.route('/weddingcakescatalog')
# def catalog():
#     return render_template('weddingcakescatalog.html')
#


# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
cakes_col = db['cakes']


@weddingcakescatalog.route('/weddingcakescatalog')
def catalog():
    # Fetch weddingcakescatalog cakes
    weddingcakescatalog_cakes = cakes_col.find({"catalog_name": "birthday"})

    # Convert cursor to list
    weddingcakescatalog_list = list(weddingcakescatalog_cakes)

    return render_template('homepage.html', weddingcakescatalog_cakes=weddingcakescatalog_list)

