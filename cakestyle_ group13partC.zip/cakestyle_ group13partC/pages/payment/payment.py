from flask import Blueprint, render_template, request, redirect, url_for,session
from pymongo import MongoClient

payment = Blueprint('payment', __name__, static_folder='static', static_url_path='/pages/payment',
                   template_folder='templates')

# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
payment_details_col = db['payment_details']

# הגדרת הנתיב לעמוד התשלום
@payment.route('/payment', methods=['GET', 'POST'])
def payment_page():
    if request.method == 'POST':
        # קבלת פרטי התשלום מהטופס
        credit_card = request.form.get('creditCard')
        vd = request.form.get('vd')
        cvv = request.form.get('cvv')
        order_id = session.get('order_id')
        # יצירת אובייקט תשלום
        payment_data = {
            "order_id": order_id,
            "credit_card_number": credit_card,
            "expiry_date": vd,
            "cvv": cvv
        }

        # הוספת פרטי התשלום למסד הנתונים
        payment_details_col.insert_one(payment_data)

        return redirect(url_for('homepage.index'))

    return render_template('payment.html')
