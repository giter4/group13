from flask import Blueprint, render_template, request, session, redirect
from pymongo import MongoClient


birthdaycakescatalog = Blueprint('birthdaycakescatalog', __name__, static_folder='static', static_url_path='/pages/birthdaycakescatalog',
                   template_folder='templates')


# @birthdaycakescatalog.route('/birthdaycakescatalog')
# def catalog():
#     return render_template('birthdaycakescatalog.html')


# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
cakes_col = db['cakes']


@birthdaycakescatalog.route('/birthdaycakescatalog')
def catalog():
    # Fetch birthdaycakescatalog cakes
    birthdaycakescatalog_cakes = cakes_col.find({"catalog_name": "birthday"})

    # Convert cursor to list
    birthdaycakescatalog_list = list(birthdaycakescatalog_cakes)

    return render_template('homepage.html', birthdaycakescatalog_cakes=birthdaycakescatalog_list)

