from flask import Blueprint, render_template, request, session, redirect
from pymongo import MongoClient


babyshowercakescatalog = Blueprint('babyshowercakescatalog', __name__, static_folder='static', static_url_path='/pages/babyshowercakescatalog',
                   template_folder='templates')





# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
cakes_col = db['cakes']


@babyshowercakescatalog.route('/babyshowercakescatalog')
def catalog():
    # Fetch babyshowercakescatalog cakes
    babyshowercakescatalog_cakes = cakes_col.find({"catalog_name": "baby_shower"})

    # Convert cursor to list
    babyshowercakescatalog_cakes_list = list( babyshowercakescatalog_cakes)

    return render_template('homepage.html', babyshowercakescatalog_cakes=babyshowercakescatalog_cakes_list )

