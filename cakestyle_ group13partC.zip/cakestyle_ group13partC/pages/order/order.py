from flask import Blueprint, render_template, request, session, redirect, url_for
from pymongo import MongoClient
from datetime import datetime

order = Blueprint('order', __name__, static_folder='static', static_url_path='/pages/order/static',
                  template_folder='templates')

# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
orders_col = db['orders']


@order.route('/order', methods=['GET', 'POST'])
def order_view():
    if 'user_id' not in session:
        return redirect(url_for('login.login_page'))

    if request.method == 'POST':
        # Extract order details from the form
        order_details = {
            'order_id': orders_col.count_documents({}) + 1,
            'DT': datetime.now().strftime('%Y-%m-%d'),
            'user_email': session.get('user_email'),
            'cake_id': session.get('cake_id'),
            'size': request.form.get('size'),
            'inscription': session.get('cake_design', {}).get('cake_inscription'),
            'coating_color': session.get('cake_design', {}).get('coating_color'),
            'kosher': session.get('cake_design', {}).get('kosher'),
            'allergy_info': session.get('cake_design', {}).get('allergy_info'),
            'notes': session.get('cake_design', {}).get('notes'),
            'quantity': session.get('cake_design', {}).get('quantity'),
            'extra_price': request.form.get('extra_price', 0.0),
            'unit_price': request.form.get('unit_price', 0.0),
            'total_price': float(request.form.get('extra_price', 0.0)) + float(request.form.get('unit_price', 0.0)),
            'delivery_date': request.form.get('delivery_date'),
            'address': request.form.get('delivery_address') if request.form.get('receive_type') == 'delivery' else ''
        }

        result = orders_col.insert_one(order_details)
        order_id = result.inserted_id

        session['order_id'] = str(order_id)
        return redirect(url_for('homepage.index'))

    return render_template('order.html')
