from flask import Blueprint, render_template, request, session, redirect
from pymongo import MongoClient

homepage = Blueprint('homepage', __name__, static_folder='static', static_url_path='/pages/homepage',
                   template_folder='templates')



# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
cakes_col = db['cakes']


@homepage.route('/')
def index():
    # Fetch recommended cakes
    recommended_cakes = cakes_col.find({"recommended": True})

    # Convert cursor to list
    recommended_cakes_list = list(recommended_cakes)

    return render_template('homepage.html', recommended_cakes=recommended_cakes_list )

