console.log('Homepage.js is loaded');

// Function to start animation
function startAnimation(element) {
    element.classList.add('event_celebration_icon_animation');
}

// Function to stop animation
function stopAnimation(element) {
    element.classList.remove('event_celebration_icon_animation');
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('User logged in:', isLoggedIn);

    if (!isLoggedIn) {
        // cake item clicks to login page
        const cakeItems = document.querySelectorAll('.cake_item');
        console.log('Cake items found:', cakeItems.length); // Print number of cake items found
        cakeItems.forEach(item => {
            console.log('Adding click listener to cake item:', item); // Print each item
            item.addEventListener('click', function() {
                console.log('Cake item clicked, redirecting to login'); // Print on click
                window.location.href = '/login'; // Redirect to login page
            });
        });

        // user icon clicks to login page
        const userIcon = document.getElementById('personal_account'); // Ensure the ID matches the HTML
        if (userIcon) {
            userIcon.addEventListener('click', function() {
                console.log('User icon clicked, redirecting to login'); // Print on click
                window.location.href = '/login'; // Redirect to login page
            });
        }

        // login link clicks to login page
        const loginLink = document.getElementById('login_link'); // Ensure the ID matches the HTML
        if (loginLink) {
            loginLink.addEventListener('click', function() {
                console.log('Login link clicked, redirecting to login'); // Print on click
                window.location.href = '/login'; // Redirect to login page
            });
        }
    }
    else {
        // Redirect to homepage if the user is logged in
        window.location.href = '/design_cake'; // Redirect to homepage
        }
});