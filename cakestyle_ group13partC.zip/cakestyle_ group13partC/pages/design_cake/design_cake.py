from flask import Blueprint, render_template, request, session, redirect, url_for

design_cake = Blueprint('design_cake', __name__, static_folder='static', static_url_path='/pages/design_cake/static', template_folder='templates')

@design_cake.route('/design_cake/<int:cake_id>', methods=['GET', 'POST'])
def show_design_cake(cake_id):
    if 'user_id' not in session:
        return redirect(url_for('login.login_page'))

    if request.method == 'POST':
        # Extract cake design data from the form
        cake_design = {
            'cake_inscription': request.form.get('cake_inscription'),
            'coating_color': request.form.get('coating_color'),
            'kosher': request.form.get('kosher') == 'yes',
            'allergy_info': request.form.get('allergy_info'),
            'notes': request.form.get('notes'),
            'quantity': int(request.form.get('quantity'))
        }
        session['cake_design'] = cake_design  # Save cake design to session

        return redirect(url_for('order.order_view'))

    return render_template('design_cake.html', cake_id=cake_id)

@design_cake.route('/design_cake', methods=['GET'])
def design_cake_view():
    if 'user_id' not in session:
        return redirect(url_for('login.login_page'))
    return render_template('design_cake.html')
