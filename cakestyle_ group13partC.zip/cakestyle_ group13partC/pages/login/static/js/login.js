document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        console.log('Form submitted');

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        fetch('/pages/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                window.location.href = '/';
            } else {
                document.querySelector('.error').textContent = data.message;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    // בדוק אם המשתמש מחובר
    fetch('/check_login', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.logged_in) {
            const profileLink = document.getElementById('profile-link');
            if (profileLink) {
                profileLink.addEventListener('click', function(event) {
                    event.preventDefault();
                    window.location.href = '/userProfile';  // מעבר לעמוד פרופיל אישי
                });
            }
        } else {
            const profileLink = document.getElementById('profile-link');
            if (profileLink) {
                profileLink.addEventListener('click', function(event) {
                    event.preventDefault();
                    alert('You are not logged in');
                });
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
