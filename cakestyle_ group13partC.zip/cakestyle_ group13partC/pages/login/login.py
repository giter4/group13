from flask import Blueprint, render_template, request, session, jsonify, redirect, url_for

from pymongo import MongoClient

login = Blueprint('login', __name__, static_folder='static', static_url_path='/pages/login', template_folder='templates')

# MongoDB connection
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)
db = client['cakestyle_db']
user_col = db['users']

@login.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check the user's credentials
        user = user_col.find_one({'email': email})

        if user and (user['password'], password):
            session['email'] = email
            return jsonify({'success': True, 'redirect_url': url_for('homepage.index')})
        else:
            return jsonify({'success': False, 'message': 'Invalid credentials. Please try again.'})

    if 'email' in session:
        return redirect(url_for('homepage.index'))

    return render_template('login.html', error_message=None)

