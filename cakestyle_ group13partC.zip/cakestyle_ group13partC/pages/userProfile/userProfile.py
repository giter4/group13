from flask import Blueprint, redirect, url_for, render_template, session


userProfile = Blueprint('userProfile', __name__, static_folder='static', static_url_path='/pages/userProfile',
                   template_folder='templates')



@userProfile.route('/userProfile')
def userProfile_view():
    # בדיקה אם המשתמש מחובר
    if 'user_id' not in session:
        # הפנייה לעמוד הכניסה אם המשתמש אינו מחובר
        return redirect(url_for('login.login_page'))

    # הצגת עמוד פרופיל המשתמש אם המשתמש מחובר
    return render_template('/userProfile.html')