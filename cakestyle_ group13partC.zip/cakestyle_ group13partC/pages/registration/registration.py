from flask import Blueprint, render_template, request, redirect, url_for
from pymongo import MongoClient
from pymongo.server_api import ServerApi

# Initialize MongoDB client
uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
cluster = MongoClient(uri, server_api=ServerApi('1'))
db = cluster['cakestyle_db']
users_col = db['users']

registration = Blueprint(
    'registration',
    __name__,
    static_folder='static',
    static_url_path='/pages/registration',
    template_folder='templates'
)

@registration.route('/registration', methods=['GET', 'POST'])
def registration_page():
    if request.method == 'POST':
        # Extract form data from the request
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        phone = request.form.get('phone')

        user_data = {
            'email': email,
            'password': password,
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone
        }

        # Check if user already exists
        if users_col.find_one({"email": email}) is None:
            # Insert new user into the collection
            users_col.insert_one(user_data)
            print(f"Registered user: {first_name} {last_name}")
            return redirect(url_for('login.login_page'))
        else:
            print(f"User with email {email} already exists.")
            return redirect(url_for('registration.registration_page'))

    return render_template('registration.html')
