# STYLE CAKE App

## Overview

CakeStyle is an application for a cake business that allows you to order cakes for various events and customize them.
The application will allow you to save the phones in order to explain to the business owner the desired cake
design and will allow an easy, convenient and customized 
purchase in the application with an option to choose delivery/self-collection.
In addition, after ordering The cake will allow the user to rate the cake.


## App Operations
A user registers and connects to the website,
then finds a cake he wants to order,
chooses a custom design,
chooses a date for delivery/collection and pays.

- HomePage: watch the recommanded cakes and filter by the event.
  ![homepage.jpg](screenshots/homepage.jpg)
- Registration: create new account in the app.
  ![registration.jpg](screenshots/registration.jpg)
- LogIn: connect to your personal area.
  ![userProfile.jpg](screenshots/login.jpg)
- userProfile: watch your last orders.
  ![userprofile.png](screenshots/userprofile.png)
-  birthday catalog : choose an event catalog.
  ![birthdaycakescatalog](screenshots/birthdaycakescatalog.png)
-  babyShower catalog : choose an event catalog.
  ![babyshowercakescatalog](screenshots/babyshowercakescatalog.png)
- wedding catalog : choose an event catalog.
  ![wedding catalog](screenshots/weddingcatalog.jpg)
- design cake: watch cake's details and customize
  ![design cake](screenshots/designcake.jpg)
- payment: insert credit card and pay
  ![payment](screenshots/payment.jpg)



