import os
from pymongo import MongoClient
from dotenv import load_dotenv
load_dotenv()
db_uri = os.getenv("DB_URI")

def print_all_documents(db_name):
    try:
        client = MongoClient(db_uri)

        db = client[db_name]

        collections = db.list_collection_names()

        for collection_name in collections:
            collection = db[collection_name]
            documents = collection.find()
            print(f"\nDocuments in collection '{collection_name}':")
            for doc in documents:
                print(doc)

    except Exception as e:
        print(f"An error occurred: {e}")

print_all_documents("cakestyle_db")
