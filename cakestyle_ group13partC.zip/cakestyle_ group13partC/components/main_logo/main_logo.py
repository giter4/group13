# components/main_logo/main_logo.py
from flask import Blueprint, render_template

main_logo = Blueprint('main_logo', __name__, template_folder='templates', static_folder='static')

@main_logo.route('/')
def show_logo():
    return render_template('main_logo.html')
