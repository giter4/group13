from flask import Blueprint, render_template

main_nav = Blueprint('main_nav', __name__, template_folder='templates', static_folder='static')

@main_nav.route('/')
def show_nav():
    return render_template('main_nav.html')
