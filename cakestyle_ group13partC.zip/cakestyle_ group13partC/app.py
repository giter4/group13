from flask import Flask, redirect, url_for, session
#from flask_pymongo import PyMongo
#from flask_session import Session
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Set up configuration from environment variables
app.config['MONGO_URI'] = os.getenv('DB_URI')
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SESSION_TYPE'] = 'filesystem'

# Initialize extensions
#mongo = PyMongo(app)
#Session(app)

# Import blueprints
from components.main_logo.main_logo import main_logo
from components.main_nav.main_nav import main_nav
from pages.homepage.homepage import homepage
from pages.login.login import login
from pages.babyshowercakescatalog.babyshowercakescatalog import babyshowercakescatalog
from pages.birthdaycakescatalog.birthdaycakescatalog import birthdaycakescatalog
from pages.design_cake.design_cake import design_cake
from pages.order.order import order
from pages.payment.payment import payment
from pages.registration.registration import registration
from pages.userProfile.userProfile import userProfile
from pages.weddingcakescatalog.weddingcakescatalog import weddingcakescatalog

# Register blueprints
app.register_blueprint(main_logo, url_prefix='/main_logo')
app.register_blueprint(main_nav, url_prefix='/main_nav')
app.register_blueprint(homepage, url_prefix='/')
app.register_blueprint(login, url_prefix='/login')
app.register_blueprint(babyshowercakescatalog, url_prefix='/babyshowercakescatalog')
app.register_blueprint(birthdaycakescatalog, url_prefix='/birthdaycakescatalog')
app.register_blueprint(design_cake, url_prefix='/design_cake')
app.register_blueprint(order, url_prefix='/order')
app.register_blueprint(payment, url_prefix='/payment')
app.register_blueprint(registration, url_prefix='/registration')
app.register_blueprint(userProfile, url_prefix='/userProfile')
app.register_blueprint(weddingcakescatalog, url_prefix='/weddingcakescatalog')

if __name__ == '__main__':
    app.run(debug=True)
