####### mongodb ##################################
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

# Create a new client and connect to the server
cluster = MongoClient(uri, server_api=ServerApi('1'))
cakestyle_db = cluster['cakestyle_db']

def insert_cakes(collection, cakes):
    for cake in cakes:
        if collection.find_one({"cake_id": cake["cake_id"]}) is None:
            collection.insert_one(cake)
            print(f"Inserted cake: {cake['name']}")
        else:
            print(f"Cake {cake['name']} already exists. Skipping...")

def insert_users(collection, users):
    for user in users:
        if collection.find_one({"email": user["email"]}) is None:
            collection.insert_one(user)
            print(f"Inserted user: {user['firstName']} {user['lastName']}")
        else:
            print(f"User {user['firstName']} {user['lastName']} already exists. Skipping...")

def insert_orders(collection, orders):
    for order in orders:
        if collection.find_one({"order_id": order["order_id"]}) is None:
            collection.insert_one(order)
            print(f"Inserted order: {order['order_id']}")
        else:
            print(f"Order {order['order_id']} already exists. Skipping...")


    #############################  שאילתות ################################


    uri = "mongodb+srv://henshaba:qweasd@cluster0.s1qhflg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

    client = MongoClient(uri, server_api=ServerApi('1'))
    db = client['cakestyle_db']
    cakes_col = db['cakes']

    #######################  שאילתת בחירה שמסננת עוגות שמחירם גבוהה מ100  ####################
    pipeline = [
        {"$match": {"base_price": {"$gt": 100}}},  # סינון עוגות לפי מחיר גבוה מ-100
        {"$lookup": {
            "from": "ratings",
            "localField": "cake_id",
            "foreignField": "cake_id",
            "as": "ratings"
        }},
        {"$addFields": {
            "average_rating": {"$avg": "$ratings.rating"}
        }},
        {"$project": {
            "name": 1,
            "description": 1,
            "base_price": 1,
            "style_name": 1,
            "event_name": 1,
            "allergy_info": 1,
            "image_url": 1,
            "catalog_name": 1,
            "recommended": 1,
            "average_rating": 1
        }}
    ]

    results = cakes_col.aggregate(pipeline)

    # הצגת התוצאות
    for cake in results:
        print(cake)



###########################שאילתת הוספת עוגה חדש ##############################

    cakes_col.insert_one({
        "cake_id": 10,
        "name": "Gourmet Chocolate Cake",
        "description": "A luxurious gourmet chocolate cake.",
        "base_price": 120.00,
        "style_name": "Gourmet",
        "event_name": "birthday",
        "allergy_info": "Contains nuts",
        "image_url": "pic/Gourmet Chocolate Cake.jpg",
        "catalog_name": "birthday",
        "recommended": True,
        "rating": None
    })

    print("Inserted new cake: Gourmet Chocolate Cake")

 ###############################שאילתת מחיקה עבור עוגות שהדירוג שלהן קטן מ3 ###########################

    result = cakes_col.delete_many({"rating": {"$lt": 3}})

  ############################################ שאילתת עדכון מחיר עוגה ###########################################

    # העוגה שנרצה לעדכן
    cake_id_to_update = 5
    new_price = 75.00

    # שאילתת עדכון
    result = cakes_col.update_one(
        {"cake_id": cake_id_to_update},
        {"$set": {"base_price": new_price}}
    )


    ###################################################################

    cakes_col = cakestyle_db['cakes']

    def insert_cakes(cakes):
        for cake in cakes:
            if cakes_col.find_one({"cake_id": cake["cake_id"]}) is None:
                cakes_col.insert_one(cake)
                print(f"Inserted cake: {cake['name']}")
            else:
                print(f"Cake {cake['name']} already exists. Skipping...")

    all_cakes = [
        # Baby Shower Cakes
        {
            "cake_id": 1,
            "name": 'Pink Baby Shower Cake',
            "description": 'A delightful pink cake for a baby shower.',
            "base_price": 80.00,
            "style_name": 'Pink',
            "event_name": 'baby shower',
            "allergy_info": 'none',
            "image_url": 'pic/Pink Baby Shower Cake.jpg',
            "catalog_name": 'baby_shower',
            "recommended": False,
            "rating": 4
        },
        {
            "cake_id": 2,
            "name": 'Blue Baby Shower Cake',
            "description": 'A sweet blue cake for a baby shower.',
            "base_price": 85.00,
            "style_name": 'Blue',
            "event_name": 'baby shower',
            "allergy_info": 'Dairy',
            "image_url": 'pic/Blue Baby Shower Cake.jpg',
            "catalog_name": 'baby_shower',
            "recommended": False,
            "rating": 5
        },
        {
            "cake_id": 3,
            "name": 'Animal Themed Baby Shower Cake',
            "description": 'A cute animal-themed cake for a baby shower.',
            "base_price": 90.00,
            "style_name": 'Animal',
            "event_name": 'baby shower',
            "allergy_info": 'none',
            "image_url": 'pic/Animal Themed Baby Shower Cake.jpg',
            "catalog_name": 'baby_shower',
            "recommended": False,
            "rating": 5
        },
        # Birthday Cakes
        {
            "cake_id": 4,
            "name": 'Fun Birthday Cake',
            "description": 'A fun and colorful birthday cake for celebrations.',
            "base_price": 50.00,
            "style_name": 'Fun',
            "event_name": 'birthday',
            "allergy_info": 'none',
            "image_url": 'pic/Fun Birthday Cake.jpg',
            "catalog_name": 'birthday',
            "recommended": False,
            "rating": 4
        },
        {
            "cake_id": 5,
            "name": 'Classic Chocolate Birthday Cake',
            "description": 'A classic chocolate cake for birthdays.',
            "base_price": 60.00,
            "style_name": 'Classic',
            "event_name": 'birthday',
            "allergy_info": 'Gluten',
            "image_url": 'pic/Classic Chocolate Birthday Cake.jpg',
            "catalog_name": 'birthday',
            "recommended": True,
            "rating": 5
        },
        {
            "cake_id": 6,
            "name": 'Unicorn Birthday Cake',
            "description": 'A magical unicorn-themed birthday cake.',
            "base_price": 70.00,
            "style_name": 'Unicorn',
            "event_name": 'birthday',
            "allergy_info": 'none',
            "image_url": 'pic/Unicorn Birthday Cake.jpg',
            "catalog_name": 'birthday',
            "recommended": False,
            "rating": 4
        },
        # Wedding Cakes
        {
            "cake_id": 7,
            "name": 'Elegant White Wedding Cake',
            "description": 'A beautiful white wedding cake with intricate designs.',
            "base_price": 250.00,
            "style_name": 'Traditional',
            "event_name": 'wedding',
            "allergy_info": 'none',
            "image_url": "pic/white cake.jpg",
            "catalog_name": 'wedding',
            "recommended": False,
            "rating": 3
        },
        {
            "cake_id": 8,
            "name": 'Rustic Wedding Cake',
            "description": 'A charming rustic wedding cake with a natural look.',
            "base_price": 300.00,
            "style_name": 'Rustic',
            "event_name": 'wedding',
            "allergy_info": 'gluten',
            "image_url": 'pic/rustic wedding cake.jpg',
            "catalog_name": 'wedding',
            "recommended": True,
            "rating": 5
        },
        {
            "cake_id": 9,
            "name": 'Floral Wedding Cake',
            "description": 'A stunning wedding cake adorned with edible flowers.',
            "base_price": 350.00,
            "style_name": 'Floral',
            "event_name": 'wedding',
            "allergy_info": 'none',
            "image_url": 'pic/Floral Wedding Cake.jpeg',
            "catalog_name": 'wedding',
            "recommended": False,
            "rating": 4
        }
    ]

    insert_cakes(all_cakes)

    #####################################################


users_col = cakestyle_db['users']

users = [
    {
        "email": "example@example.com",
        "password": "password",
        "firstName": "John",
        "lastName": "Doe",
        "phone": "1234567890"
    }
]

insert_users(users_col, users)



#####################################################

orders_col = cakestyle_db['orders']

orders = [
    {
        "order_id": 1,
        "DT": "2024-06-21",
        "user_email": "example@example.com",
        "cake_id": 1,
        "size": "Medium",
        "inscription": "Happy Birthday",
        "coating_color": "Blue",
        "kosher": True,
        "allergy_info": "Contains nuts",
        "notes": "Handle with care",
        "quantity": 1,
        "extra_price": 10.50,
        "unit_price": 25.00,
        "total_price": 35.50,
        "delivery_date": "2024-06-25",
        "address": "123 Main St, Anytown, USA"
    },
    {
        "order_id": 2,
        "DT": "2024-06-22",
        "user_email": "example@example.com",
        "cake_id": 2,
        "size": "Large",
        "inscription": "Congratulations",
        "coating_color": "Pink",
        "kosher": False,
        "allergy_info": "",
        "notes": "",
        "quantity": 2,
        "extra_price": 0,
        "unit_price": 30.00,
        "total_price": 60.00,
        "delivery_date": "2024-06-27",
        "address": "456 Elm St, Othertown, USA"
    }
]

insert_orders(orders_col, orders)

###############################################################
cakes_col = cakestyle_db['cakes']
ratings_col = cakestyle_db['ratings']

# Insert ratings
ratings = [
    {
        "cake_id": 1,
        "user_email": "example@example.com",
        "rating": 5
    },
    {
        "cake_id": 2,
        "user_email": "example@example.com",
        "rating": 4
    }
]

def insert_ratings(collection, ratings):
    for rating in ratings:
        if collection.find_one({"cake_id": rating["cake_id"], "user_email": rating["user_email"]}) is None:
            collection.insert_one(rating)
            print(f"Inserted rating for cake ID {rating['cake_id']} by {rating['user_email']}")
        else:
            print(f"Rating for cake ID {rating['cake_id']} by {rating['user_email']} already exists. Skipping...")

insert_ratings(ratings_col, ratings)

# Update average ratings
def update_average_ratings(cakes_collection, ratings_collection):
    pipeline = [
        {"$group": {
            "_id": "$cake_id",
            "average_rating": {"$avg": "$rating"},
            "rating_count": {"$sum": 1}
        }}
    ]
    results = list(ratings_collection.aggregate(pipeline))

    for result in results:
        cakes_collection.update_one(
            {"cake_id": result["_id"]},
            {"$set": {"average_rating": result["average_rating"], "rating_count": result["rating_count"]}}
        )

update_average_ratings(cakes_col, ratings_col)

 ###############################################################
payment_details_col = cakestyle_db['payment_details']

def insert_payment_details(collection, details):
    for detail in details:
        if collection.find_one({"order_id": detail["order_id"]}) is None:
            collection.insert_one(detail)
            print(f"Inserted payment details for order ID {detail['order_id']}")
        else:
            print(f"Payment details for order ID {detail['order_id']} already exists. Skipping...")


# Payment details data
payment_details = [
    {
        "order_id": 1,
        "credit_card_number": "1234567812345678",
        "expiry_date": "12/2025",
        "cvv": "123"
    },
    {
        "order_id": 2,
        "credit_card_number": "8765432187654321",
        "expiry_date": "11/2026",
        "cvv": "321"
    }
]

insert_payment_details(payment_details_col, payment_details)



# user functions
def find_user(email):
    return users_col.find_one({'email': email})


def insert_user(user):
    return users_col.insert_one(user)

# end - user functions


# order function
def find_last_orders (userId):
    return cakes_col.find_many({'cakes':cakes_col})
# end - order function